package wwae;

public enum Difficulty {
    LOW,
    MEDIUM,
    HARD
}
